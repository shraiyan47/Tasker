<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\blog;
use Faker\Generator as Faker;

$factory->define(blog::class, function (Faker $faker) {
    return [
        //
    ];
});
