@extends('layout')

@section('title')
	{{$post->title}}
@endsection

@section('content')

	<h2>Edit Blog Post : {{ $post->title}}</h2>

		<form method="POST" action="/blog/{{ $post->id}}" class="form">
	
			@method('PATCH')
				@csrf

{{-- 			{{ method_field('PATCH') }}

			{{ csrf_field() }} --}}

			Edit Title: <input type="text" name="title" placeholder="Edit Blog Post Title" value="{{ $post->title }}" class="form-control {{ $errors->has('title') ? 'is-danger' : '' }}"><br>

			Edit Description:
			<textarea name="description" placeholder="Edit Description" class="form-control {{ $errors->has('description') ? 'is-danger' : '' }}"> {{ $post->description }}</textarea><br>

			<button class="btn btn-primary" type="submit" >Update Post</button> 
			
			@if($errors->any())

						<div class="notification is-danger">
							
							<ul>
								
								@foreach($errors->all() as $error)

								<li>
									{{ $error }}
								</li>

								@endforeach

							</ul>

						</div>

			@endif
</form>

	<div>
		
		Are you sure that you want to delete {{$post->title}} ?

			<br>
			<br>

		<form method="POST" action="/blog/{{ $post->id }}">
				
			{{-- 	{{ method_field('DELETE')}}
				{{ csrf_field() }} --}}

				@method('DELETE')
				@csrf

					<button type="submit" class="btn btn-primary" >Delete post</button>

			

		</form>

	</div>

@endsection