 @extends('layout')

 @section('title','{{$post->title}}')

 @section('content')


<div class="col-lg-2"></div>
<div class="col-lg-7">
<div> 
	<h1 align="center">{{$post->title}}</h1>
</div>
<div>{{$post->description}}</div>
</div>
<div class="col-lg-3"></div>

@endsection