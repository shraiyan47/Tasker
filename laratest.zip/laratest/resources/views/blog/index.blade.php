 @extends('layout')

 @section('title','BLOG')

 @section('content')


<div class="row">
	<div class="col-lg-12">
		<h1 align="center">WELCOME TO BLOG WRITING</h1>
	</div>
</div>

<div class="row">
<div class="col-lg-2"></div>

<div class="col-lg-7">
	

<div>
	<h2>Blog Feed:</h2>
</div>

@foreach($post as $posts)
<div>

	<div class="container">

		<li>
			<div class="title">
				<h3>{{ $posts->id }}  <a href="/blog/{{ $posts->id }}">{{ $posts->title }}</a></h3> 
				
			</div>

			<div>
				<h5> 
					
					<a href="/blog/{{ $posts->id }}/edit">
						<button class="btn btn-primary">
							Edit/Delete
						</button>
					</a>
				</h5> 
			</div>
		</li>

		</div>
	
</div>

@endforeach

</div>

<div class="col-lg-3"></div>

	
</div>


 @endsection