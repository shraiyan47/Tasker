 @extends('layout')

 @section('title','BLOG')

 @section('content')


<div class="container"> <h1 align="center">Write Your Blog Here</h1> </div>

<div>
	<form method="post" action="/blog" class="form">

		{{ csrf_field() }}

			<div class="form-group">
				<label for="title">Blog Title: </label>
					<div class="control"> 
						<input type="text" name="title" placeholder="Blog Title" class="form-control {{ $errors->has('title') ? 'is-danger' : '' }}" id="title">	
					</div>
			
			</div>

			<div class="form-group">
				<textarea name="description" placeholder="Blog description" class="	form-control {{ $errors->has('title') ? 'is-danger' : '' }}" ></textarea>

			</div>
			
			<div>
				<button class="btn btn-primary" type="submit"> Create Blog</button>
			</div>
	</form>
</div>




@endsection

@if($errors->any())

			<div class="notification is-danger">
				
				<ul>
					
					@foreach($errors->all() as $error)

					<li>
						{{ $error }}
					</li>

					@endforeach

				</ul>

			</div>

@endif