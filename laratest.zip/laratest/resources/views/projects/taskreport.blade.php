@extends('layout')

@section('title')

  {{$project->title}}

@endsection


@section('content')

<h1>Task Report</h1>

<div id="piechart"></div>

<!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
 -->    
 <script type="text/javascript" src="{{ asset('js/loader.js') }}"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Percentage'],
  ['Attendance', 90],
  ['Time Maintain', 80],
  ['Task Complition', 100],
  ['Task Evaluation', 80]
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'My Average Day', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.BarChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

@endsection