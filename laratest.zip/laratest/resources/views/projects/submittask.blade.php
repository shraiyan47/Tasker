@extends('layout')

@section('title')

	{{$project->title}}

@endsection


@section('content')

		<h2>Edit Project</h2>

		<form method="POST" action="/projects/{{ $project->id}}" class="form">
			
			{{ method_field('PATCH') }}

			{{ csrf_field() }}

			Task Title: <input type="text" name="title" placeholder="Edit Title" value="{{ $project->title }}" class="form-control {{ $errors->has('title') ? 'is-danger' : '' }}"><br>

		  Task File: 

      <input type="file" name="file">

			<button class="btn btn-primary" type="submit" >Update Project</button> 
			@if($errors->any())

						<div class="notification is-danger">
							
							<ul>
								
								@foreach($errors->all() as $error)

								<li>
									{{ $error }}
								</li>

								@endforeach

							</ul>

						</div>

			@endif
</form>
@endsection