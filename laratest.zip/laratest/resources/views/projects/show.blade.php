@extends('layout')


@section('title')

	{{$project->title}}

@endsection



@section('content')


<div>
	
	<h1> {{$project->title}} </h1>

</div>

<DIV>
	<h2>Task Description:</h2>
	<h3>{{$project->description}} </h3><br><br>

</DIV>

<div>
	<h4>Task Deadline:</h4>
	<b>Date: {{$project->deadlinedate}} Time:  {{$project->deadlinetime}} </b>

</div>

<a href="/projects/{{$project->id}}/taskreport"><button class="btn btn-primary">Task Report</button></a>
<a href="/projects/{{$project->id}}/submittask"><button class="btn btn-primary">Task Submit</button></a>

@endsection