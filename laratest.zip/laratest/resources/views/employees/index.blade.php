@extends('layout')

@section('title','Employees')

@section('content')


<h1>Employees List</h1>

@foreach ($employer as $employe)

<div class="container">

		<li>
			<div class="username">
				<h3>{{ $employe->id }}  <a href="/employees/{{ $employe->id }}">{{ $employe->username }}</a></h3> 
				<h4>Designation: {{ $employe->designation}}</h4>
	
			</div>

			<div>
				<h5> 
					
					<a href="/employees/{{$employe->id}}/editemployee">
						<button class="btn btn-primary">
							Edit
						</button>
					</a>
				</h5> 
			</div>
		</li>

		</div>


@endforeach

@endsection