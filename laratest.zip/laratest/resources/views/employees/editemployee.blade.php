@extends('layout');


@section('title','edit');

@section('content')

<h1>Edit Employee</h1>

<form method="POST" action="/employees/{{$employer->id}}" class="form">

	{{ method_field('PATCH') }}
	{{ csrf_field() }}


	<div class="form-group">
      <label for="username">Username:</label>
      <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" value="{{$employer->username}}">
    </div>
    <div class="form-group">
      <label for="mobilenumber">Mobile Number:</label>
      <input type="number" class="form-control" id="mobilenumber" placeholder="Enter mobilenumber" name="contact" value="{{$employer->contact}}">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="{{$employer->email}}">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" value="{{$employer->password}}">
    </div>

    <div class="panel panel-danger"><div class="panel-heading"><b>Please, check your Gender Again.</b></div></div>
    <div class="form-group">
      <label for="gender"> Gender: </label>
        <label><input type="radio" name="gender" value="male"> Male</label>
        <label><input type="radio" name="gender" value="female"> Female</label>
        <label><input type="radio" name="gender" value="other"> Other</label>
    </div>
    <div class="form-group">
      <label for="designation">Designation</label>
      <input type="text" name="designation" id="designation" placeholder="Enter Designation" class="form-control" value="{{$employer->designation}}">
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
	
</form>


<form method="POST" action="/employees/{{ $employer->id }}">
				
				{{ method_field('DELETE')}}
				{{ csrf_field() }}
				<h1>Are you sure you want to delete {{$employer->username}} ??</h1>

					<button type="submit" class="btn btn-primary" >Delete Project</button>

			

		</form>
@endsection
