@extends('layout')

@section('title')

	{{$employer->username}}

@endsection


@section('content')


<form method="POST" action="/employees/{{ $employer->id }}">
				
				{{ method_field('DELETE')}}
				{{ csrf_field() }}
				<h1>Are you sure you want to delete {{$employer->username}} ??</h1>

					<button type="submit" class="btn btn-primary" >Delete Project</button>

			

		</form>
@endsection