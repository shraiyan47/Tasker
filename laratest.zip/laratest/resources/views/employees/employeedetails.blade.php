 @extends('layout')


@section('title')

	{{$employer->username}}

@endsection



@section('content')


<div>
	
	<h1> {{$employer->username}} </h1><br>
	<h3> {{$employer->contact}} </h3><br>
	<h3> {{$employer->email}} </h3><br>
	<h3> {{$employer->password}} </h3><br>
	<h3> {{$employer->gender}} </h3><br>
	<h3> {{$employer->designation}} </h3><br>

</div>
<div>
				<h5> 
					
					<a href="/employees/{{$employer->id}}/editemployee">
						<button class="btn btn-primary">
							Edit
						</button>
					</a>
				</h5> 
			</div>
@endsection