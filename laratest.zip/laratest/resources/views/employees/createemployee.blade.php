@extends('layout')

@section('content')
    <div><h1>Create Employee</h1></div>
    
    <div class="container">
  <h2>Employee form</h2>
  <form method="POST" action="/employees" class="form">

    {{ csrf_field() }}


    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" required>
    </div>
    <div class="form-group">
      <label for="mobilenumber">Mobile Number:</label>
      <input type="number" class="form-control" id="mobilenumber" placeholder="Enter mobilenumber" name="contact" required>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required>
    </div>
    <div class="form-group">
      <label for="gender"> Gender: </label>
        <label><input type="radio" name="gender" value="male" required> Male</label>
        <label><input type="radio" name="gender" value="female" required> Female</label>
        <label><input type="radio" name="gender" value="other" required> Other</label>
    </div>
    <div class="form-group">
      <label for="designation">Designation</label>
      <input type="text" name="designation" id="designation" placeholder="Enter Designation" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

 @if($errors->any())
  <div class="notification is-danger">
    <ul>
      
      @foreach ($errors->all() as $error)

        <li>
          {{ $error }}
        </li>

      @endforeach

    </ul>
    
  </div>
@endif
@endsection