<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*======== This is for default Authentication Process ======= */
Auth::routes();


/* ========= This is for index page and other basic pages ======== */

Route::group(['middleware'=>['preventbackbutton','auth']], function(){
	
Route::get('/','PagesController@home');
Route::get('/about','PagesController@about');
Route::get('/contact','PagesController@contact');
Route::get('/home', 'HomeController@index')->name('home');




/* ========= This is for Employee Pages ========= */

Route::get('/employees','EmployeesController@index');
Route::post('/employees', 'EmployeesController@store');
Route::get('/employees/createemployee','EmployeesController@create');
Route::get('/employees/{employer}', 'EmployeesController@show');
Route::get('/employees/{employer}/editemployee', 'EmployeesController@edit');
Route::patch('/employees/{employer}', 'EmployeesController@update');
Route::delete('/employees/{employer}', 'EmployeesController@destroy');


/*===This is all for the projectsController Routes====*/

/*   Route::resource('projects','projectsController');    */

Route::get('/projects', 'projectsController@index');
Route::POST('/projects', 'projectsController@store');
Route::get('/projects/create', 'projectsController@create');
Route::get('/projects/{project}', 'projectsController@show');
Route::get('/projects/{project}/edit', 'projectsController@edit');
Route::patch('/projects/{project}', 'projectsController@update');
Route::delete('/projects/{project}', 'projectsController@destroy');
Route::get('/projects/{project}/submittask', 'projectsController@submittask');
Route::get('/projects/{project}/taskreport', 'projectsController@taskreport');




/*=== This is all for the Bloging Controller Routes ===*/

/*Route::get('/blog', 'BlogController@index');
Route::get('/blog/create', 'BlogController@create');
Route::post('/blog', 'BlogController@store');
Route::get('/blog/{post}', 'BlogController@show');
Route::get('/blog/{post}/edit', 'BlogController@edit');
Route::patch('/blog/{post}', 'BlogController@update');
Route::delete('/blog/{post}', 'BlogController@destroy');*/


Route::resource('blog','BlogController');

});