<?php

namespace App\Http\Controllers;

use App\laratable;

use Illuminate\Http\Request;

class projectsController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }
	
	public function index()
	{
		 $projects = laratable::all();

		// return $projects;

		return view('projects.index', compact('projects'));
	}


	public function create()
	{


		return view('projects.create');

	}

	public function show(laratable $project)
	{

	//	return $project;

	//	$project = laratable::findOrFail($id);

		return view('projects.show', compact('project'));

	}

	public function edit(laratable $project)
	{

//		return $id;

	//	$project = laratable::findOrFail($id);

		return view('projects.edit', compact('project'));

	}

	public function update(laratable $project)
	{

		// dd(request()->all());

		/* $project = laratable::findOrFail(); */


		$project->update(request('title','description','deadlinedate','deadlinetime'));

	/*	$project->title = request('title');
		$project->description = request('description');

		$project->save();*/

		return redirect('/projects');

	}

	public function destroy(laratable $project)
	{

		// dd('Hello', $id);


		// laratable::findOrFail($id)->delete();

		$project->delete();

		return redirect('/projects');

	}


	public function store()
	{ 



		request()->validate([

			'title' => 'required',
			'description' => 'required',
			'deadlinedate' => 'required',
			'deadlinetime' => 'required'

		]);

		// dd(request()->all());

		laratable::create(request(['title','description','deadlinedate','deadlinetime']));

	return redirect('/projects');

/*		laratable::create([

			'title'=> request('title'),
			'description' => request('description')

		]);*/


//		return request()->all();

/*		$project = new laratable();

		$project->title = request('title');
		$project->description = request('description');

		$project->save();*/

		
	}

		public function submittask(laratable $project)
	{

//		return $id;

	//	$project = laratable::findOrFail($id);

		return view('projects.submittask', compact('project'));

	}


		public function taskreport(laratable $project)
	{

//		return $id;

	//	$project = laratable::findOrFail($id);

		return view('projects.taskreport', compact('project'));

	}

}
