<?php

namespace App\Http\Controllers;

use App\blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $post = blog::all();
        return view('blog.index',compact('post'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        return view('blog.create');   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        request()->validate([

            'title' => 'required',
            'description' => 'required'

        ]);

        blog::create(request(['title','description']));
        return redirect('/blog');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         //dd('hello'.$id);

        $post = blog::findOrFail($id);
        
        return view('blog.show', compact('post'));
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       // $post = blog::find($id);
       // dd('hello'.$id.$post);
       $post = blog::findOrFail($id);
        return view('blog.edit', compact('post'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,blog $post,$id)
    {
        request()->validate([

            'title' => 'required',
            'description' => 'required'

        ]);
       $post = blog::findOrFail($id);
  
   
         $post ->update(request(['title','description']));
        
        return redirect('/blog');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function destroy(blog $post)
    {
        $post->delete();

        return redirect('/blog');
    }
}
