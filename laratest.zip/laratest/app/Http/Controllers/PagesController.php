<?php

namespace App\Http\Controllers;

use Session;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    Public function home()
    {
    	/*
        $task = [
		'Go to the Market',
		'Go to the College',
		'Go to Home'

	];


    return view('welcome')->withTask($task)->withlara('LaraTest');
    */

    return view('index');
    }

    Public function about()
    {
    	return view('about');

    }



    public function contact()
    {
        return view('contact');
    }
    

 
}
