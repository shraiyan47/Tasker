<?php

namespace App\Http\Controllers;

use App\Workers; 

use Illuminate\Http\Request;

class EmployeesController extends Controller
{
        public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employer = Workers::all();

        return view('employees.index', compact('employer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employees.createemployee');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        request()->validate(
            [
                'username'=> 'required',
                'contact'=> 'required',
                'email'=> 'required',
                'password'=> 'required',
                'gender'=> 'required',
                'designation'=> 'required',

            ]
        );

        $emp = new workers();

        $emp->username = request('username');
        $emp->contact = request('contact');
        $emp->email = request('email');
        $emp->password = request('password');
        $emp->gender = request('gender');
        $emp->designation = request('designation');

        $emp->save();

        return redirect('/employees');

/*        return request()->all(); */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $employer = Workers::find($id);
        return view('employees.employeedetails', compact('employer'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employer = Workers::find($id);
        return view('employees.editemployee', compact('employer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
         request()->validate(
            [
                'username'=> 'required|string',
                'contact'=> 'required',
                'email'=> 'required|string',
                'password'=> 'required|string',
                'gender'=> 'required',
                'designation'=> 'required|string',

            ]
        );

        $emp = Workers::find($id);

        $emp->username = request('username');
        $emp->contact = request('contact');
        $emp->email = request('email');
        $emp->password = request('password');
        $emp->gender = request('gender');
        $emp->designation = request('designation');

        $emp->save();

        /*$employer::update(request('username','contact','email','password','gender','designation'));*/

        return redirect('/employees');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $employer = Workers::find($id);
        return view('employees.editemployee', compact('employer'));
    }

    public function destroy(Workers $employer)
    {
        $employer->delete();

        return redirect('/employees');
    }
}
