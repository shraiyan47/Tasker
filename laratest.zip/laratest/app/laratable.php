<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class laratable extends Model
{
	
	protected $fillable = [

		'title','description','deadlinedate','deadlinetime' 
	];

/*	protected $guarded = [];*/

}
