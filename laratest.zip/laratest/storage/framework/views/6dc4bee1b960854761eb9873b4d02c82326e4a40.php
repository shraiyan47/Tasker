 


<?php $__env->startSection('title'); ?>

	<?php echo e($employer->username); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<div>
	
	<h1> <?php echo e($employer->username); ?> </h1><br>
	<h3> <?php echo e($employer->contact); ?> </h3><br>
	<h3> <?php echo e($employer->email); ?> </h3><br>
	<h3> <?php echo e($employer->password); ?> </h3><br>
	<h3> <?php echo e($employer->gender); ?> </h3><br>
	<h3> <?php echo e($employer->designation); ?> </h3><br>

</div>
<div>
				<h5> 
					
					<a href="/employees/<?php echo e($employer->id); ?>/editemployee">
						<button class="btn btn-primary">
							Edit
						</button>
					</a>
				</h5> 
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/employees/employeedetails.blade.php ENDPATH**/ ?>