<?php $__env->startSection('title','Employees'); ?>

<?php $__env->startSection('content'); ?>


<h1>Employees List</h1>

<?php $__currentLoopData = $employer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container">

		<li>
			<div class="username">
				<h3><?php echo e($employe->id); ?>  <a href="/employees/<?php echo e($employe->id); ?>"><?php echo e($employe->username); ?></a></h3> 
				<h4>Designation: <?php echo e($employe->designation); ?></h4>
	
			</div>

			<div>
				<h5> 
					
					<a href="/employees/<?php echo e($employe->id); ?>/editemployee">
						<button class="btn btn-primary">
							Edit
						</button>
					</a>
				</h5> 
			</div>
		</li>

		</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/employees/index.blade.php ENDPATH**/ ?>