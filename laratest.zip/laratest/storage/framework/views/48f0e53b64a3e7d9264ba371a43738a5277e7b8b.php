<?php $__env->startSection('title'); ?>
	<?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h2>Edit Blog Post : <?php echo e($post->title); ?></h2>

		<form method="POST" action="/blog/<?php echo e($post->id); ?>" class="form">
	
			<?php echo method_field('PATCH'); ?>
				<?php echo csrf_field(); ?>



			Edit Title: <input type="text" name="title" placeholder="Edit Blog Post Title" value="<?php echo e($post->title); ?>" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>"><br>

			Edit Description:
			<textarea name="description" placeholder="Edit Description" class="form-control <?php echo e($errors->has('description') ? 'is-danger' : ''); ?>"> <?php echo e($post->description); ?></textarea><br>

			<button class="btn btn-primary" type="submit" >Update Post</button> 
			
			<?php if($errors->any()): ?>

						<div class="notification is-danger">
							
							<ul>
								
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<li>
									<?php echo e($error); ?>

								</li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</ul>

						</div>

			<?php endif; ?>
</form>

	<div>
		
		Are you sure that you want to delete <?php echo e($post->title); ?> ?

			<br>
			<br>

		<form method="POST" action="/blog/<?php echo e($post->id); ?>">
				
			

				<?php echo method_field('DELETE'); ?>
				<?php echo csrf_field(); ?>

					<button type="submit" class="btn btn-primary" >Delete post</button>

			

		</form>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/blog/edit.blade.php ENDPATH**/ ?>