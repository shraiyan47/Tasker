<?php $__env->startSection('title'); ?>

	<?php echo e($project->title); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<div>
	
	<h1> <?php echo e($project->title); ?> </h1>

</div>

<DIV>
	<h2>Task Description:</h2>
	<h3><?php echo e($project->description); ?> </h3><br><br>

</DIV>

<div>
	<h4>Task Deadline:</h4>
	<b>Date: <?php echo e($project->deadlinedate); ?> Time:  <?php echo e($project->deadlinetime); ?> </b>

</div>

<a href="/projects/<?php echo e($project->id); ?>/taskreport"><button class="btn btn-primary">Task Report</button></a>
<a href="/projects/<?php echo e($project->id); ?>/submittask"><button class="btn btn-primary">Task Submit</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/projects/show.blade.php ENDPATH**/ ?>