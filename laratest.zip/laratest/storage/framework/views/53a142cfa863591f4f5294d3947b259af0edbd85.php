<?php $__env->startSection('title'); ?>

	<?php echo e($project->title); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

		<h2>Edit Project</h2>

		<form method="POST" action="/projects/<?php echo e($project->id); ?>" class="form">
			
			<?php echo e(method_field('PATCH')); ?>


			<?php echo e(csrf_field()); ?>


			Edit Title: <input type="text" name="title" placeholder="Edit Title" value="<?php echo e($project->title); ?>" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>"><br>

			Edit Description:
			<textarea name="description" placeholder="Edit Description" class="form-control <?php echo e($errors->has('description') ? 'is-danger' : ''); ?>"><?php echo e($project->description); ?></textarea><br>

			<button class="btn btn-primary" type="submit" >Update Project</button> 
			<?php if($errors->any()): ?>

						<div class="notification is-danger">
							
							<ul>
								
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<li>
									<?php echo e($error); ?>

								</li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</ul>

						</div>

			<?php endif; ?>
</form>

			<br>
			<br>

			<form method="POST" action="/projects/<?php echo e($project->id); ?>">
				
				<?php echo e(method_field('DELETE')); ?>

				<?php echo e(csrf_field()); ?>



					<button type="submit" class="btn btn-primary" >Delete Project</button>

			

		</form>
<script>
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var radius = canvas.height / 2;
ctx.translate(radius, radius);
radius = radius * 0.90
setInterval(drawClock, 1000);

function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
  drawTime(ctx, radius);
}

function drawFace(ctx, radius) {
  var grad;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2*Math.PI);
  ctx.fillStyle = 'white';
  ctx.fill();
  grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
  grad.addColorStop(0, '#333');
  grad.addColorStop(0.5, 'white');
  grad.addColorStop(1, '#333');
  ctx.strokeStyle = grad;
  ctx.lineWidth = radius*0.1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
  ctx.fillStyle = '#333';
  ctx.fill();
}

function drawNumbers(ctx, radius) {
  var ang;
  var num;
  ctx.font = radius*0.15 + "px arial";
  ctx.textBaseline="middle";
  ctx.textAlign="center";
  for(num = 1; num < 13; num++){
    ang = num * Math.PI / 6;
    ctx.rotate(ang);
    ctx.translate(0, -radius*0.85);
    ctx.rotate(-ang);
    ctx.fillText(num.toString(), 0, 0);
    ctx.rotate(ang);
    ctx.translate(0, radius*0.85);
    ctx.rotate(-ang);
  }
}

function drawTime(ctx, radius){
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    //hour
    hour=hour%12;
    hour=(hour*Math.PI/6)+
    (minute*Math.PI/(6*60))+
    (second*Math.PI/(360*60));
    drawHand(ctx, hour, radius*0.5, radius*0.07);
    //minute
    minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
    drawHand(ctx, minute, radius*0.8, radius*0.07);
    // second
    second=(second*Math.PI/30);
    drawHand(ctx, second, radius*0.9, radius*0.02);
}

function drawHand(ctx, pos, length, width) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.moveTo(0,0);
    ctx.rotate(pos);
    ctx.lineTo(0, -length);
    ctx.stroke();
    ctx.rotate(-pos);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/projects/edit.blade.php ENDPATH**/ ?>