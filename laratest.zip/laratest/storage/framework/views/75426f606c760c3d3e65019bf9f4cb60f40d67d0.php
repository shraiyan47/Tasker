 

 <?php $__env->startSection('title','BLOG'); ?>

 <?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-lg-12">
		<h1 align="center">WELCOME TO BLOG WRITING</h1>
	</div>
</div>

<div class="row">
<div class="col-lg-2"></div>

<div class="col-lg-7">
	

<div>
	<h2>Blog Feed:</h2>
</div>

<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>

	<div class="container">

		<li>
			<div class="title">
				<h3><?php echo e($posts->id); ?>  <a href="/blog/<?php echo e($posts->id); ?>"><?php echo e($posts->title); ?></a></h3> 
				
			</div>

			<div>
				<h5> 
					
					<a href="/blog/<?php echo e($posts->id); ?>/edit">
						<button class="btn btn-primary">
							Edit/Delete
						</button>
					</a>
				</h5> 
			</div>
		</li>

		</div>
	
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div class="col-lg-3"></div>

	
</div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/blog/index.blade.php ENDPATH**/ ?>