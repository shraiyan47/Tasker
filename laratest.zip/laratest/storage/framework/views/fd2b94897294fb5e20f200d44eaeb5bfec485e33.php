<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title','LaraTest'); ?></title>

 <title>Laratest Project</title>


  <!-- Scripts -->
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  
    <link type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
   


</head>
<body>

 <nav class="navbar navbar-inverse" style="background-color:#333 ">
  <div class="container container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/">Workers Work Review</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/home">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="/projects">Projects
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="/projects">Projects</a></li>
          <li><a href="/projects/create">Create Projects</a></li>
          
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="/employee">Employee
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="/employees">Employee</a></li>
          <li><a href="/employees/createemployee">Create Employee</a></li>
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="/blog">BLOG
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="/blog">blog</a></li>
          <li><a href="/blog/create">Create blog</a></li>
        </ul>
      </li>
	<li><a href="/about">About Us</a></li>
   	<li><a href="/contact">Contact</a></li>
    </ul>

    <ul class="navbar-nav navbar-right">

                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="btn btn-primary navbar-btn" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="btn btn-primary navbar-btn" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

                            <li class="btn btn-primary navbar-btn nav-item dropdown"> 
                                <a id="navbarDropdown" class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a> 
                             
                                <div class="dropdown-menu dropdown-item" aria-labelledby="navbarDropdown">
                              
                                <a class="btn btn-primary dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>


                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                          </ul>
                        <?php endif; ?>
                    </ul>

<ul class="navbar-nav navbar-left">
               

    <canvas id="canvas" width="40" height="40">
    </canvas>

    
    <script>
          var canvas = document.getElementById("canvas");
          var ctx = canvas.getContext("2d");
          var radius = canvas.height/100;
          ctx.translate(radius, radius);
          radius = radius * 0.90
          setInterval(drawClock, 1000);

          function drawClock() {
            drawFace(ctx, radius);
            drawNumbers(ctx, radius);
            drawTime(ctx, radius);
          }

          function drawFace(ctx, radius) {
            var grad;
            ctx.beginPath();
            ctx.arc(0, 0, radius, 0, 2*Math.PI);
            ctx.fillStyle = 'white';
            ctx.fill();
            grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
            grad.addColorStop(0, '#333');
            grad.addColorStop(0.5, 'white');
            grad.addColorStop(1, '#333');
            ctx.strokeStyle = grad;
            ctx.lineWidth = radius*0.1;
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
            ctx.fillStyle = '#333';
            ctx.fill();
          }

          function drawNumbers(ctx, radius) {
            var ang;
            var num;
            ctx.font = radius*0.15 + "px arial";
            ctx.textBaseline="middle";
            ctx.textAlign="center";
            for(num = 1; num < 13; num++){
              ang = num * Math.PI / 6;
              ctx.rotate(ang);
              ctx.translate(0, -radius*0.85);
              ctx.rotate(-ang);
              ctx.fillText(num.toString(), 0, 0);
              ctx.rotate(ang);
              ctx.translate(0, radius*0.85);
              ctx.rotate(-ang);
            }
          }

          function drawTime(ctx, radius){
              var now = new Date();
              var hour = now.getHours();
              var minute = now.getMinutes();
              var second = now.getSeconds();
              //hour
              hour=hour%12;
              hour=(hour*Math.PI/6)+
              (minute*Math.PI/(6*60))+
              (second*Math.PI/(360*60));
              drawHand(ctx, hour, radius*0.5, radius*0.07);
              //minute
              minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
              drawHand(ctx, minute, radius*0.8, radius*0.07);
              // second
              second=(second*Math.PI/30);
              drawHand(ctx, second, radius*0.9, radius*0.02);
          }

          function drawHand(ctx, pos, length, width) {
              ctx.beginPath();
              ctx.lineWidth = width;
              ctx.lineCap = "round";
              ctx.moveTo(0,0);
              ctx.rotate(pos);
              ctx.lineTo(0, -length);
              ctx.stroke();
              ctx.rotate(-pos);
          } 
    </script>   
  </ul>
  </div>

</nav> 





</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="container">
                <div class="card">
                  
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>

<?php /**PATH C:\xampp\htdocs\laratest\resources\views/layout.blade.php ENDPATH**/ ?>