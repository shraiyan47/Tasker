<?php $__env->startSection('title'); ?>

	<?php echo e($project->title); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

		<h2>Edit Project</h2>

		<form method="POST" action="/projects/<?php echo e($project->id); ?>" class="form">
			
			<?php echo e(method_field('PATCH')); ?>


			<?php echo e(csrf_field()); ?>


			Task Title: <input type="text" name="title" placeholder="Edit Title" value="<?php echo e($project->title); ?>" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>"><br>

		  Task File: 

      <input type="file" name="file">

			<button class="btn btn-primary" type="submit" >Update Project</button> 
			<?php if($errors->any()): ?>

						<div class="notification is-danger">
							
							<ul>
								
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<li>
									<?php echo e($error); ?>

								</li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</ul>

						</div>

			<?php endif; ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/projects/submittask.blade.php ENDPATH**/ ?>