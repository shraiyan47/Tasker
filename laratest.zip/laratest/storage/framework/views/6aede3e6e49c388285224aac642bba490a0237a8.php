<?php $__env->startSection('content'); ?>


 <h1 align="center">My First Website <?php echo e($lara); ?> !</h1>

	
                
<ul>
    <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

    <li><?php echo e($tasks); ?></li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/welcome.blade.php ENDPATH**/ ?>