<?php $__env->startSection('title'); ?>
    
    About Page

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


 <h2 align="center">About Us</h2>

	<p>About me the page of this DJ and hip-hop artist tells you his story in different languages – English, Korean, Japanese, and Chinese. Attracting these fans makes Kero One’s brand more inclusive of all the markets he identifies with.</p>
<br>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/home/about.blade.php ENDPATH**/ ?>