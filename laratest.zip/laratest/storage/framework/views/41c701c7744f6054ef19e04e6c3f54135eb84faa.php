 

 <?php $__env->startSection('title','<?php echo e($post->title); ?>'); ?>

 <?php $__env->startSection('content'); ?>


<div class="col-lg-2"></div>
<div class="col-lg-7">
<div> 
	<h1 align="center"><?php echo e($post->title); ?></h1>
</div>
<div><?php echo e($post->description); ?></div>
</div>
<div class="col-lg-3"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratest\resources\views/blog/show.blade.php ENDPATH**/ ?>